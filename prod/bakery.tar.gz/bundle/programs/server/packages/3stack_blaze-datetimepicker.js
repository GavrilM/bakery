(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['3stack:blaze-datetimepicker'] = {};

})();

//# sourceMappingURL=3stack_blaze-datetimepicker.js.map
