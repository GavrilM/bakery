(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['3stack:datetimepicker-common'] = {};

})();

//# sourceMappingURL=3stack_datetimepicker-common.js.map
