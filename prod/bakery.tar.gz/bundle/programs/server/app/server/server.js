(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/server.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
    Bakery.remove({});                                                 // 2
    Menu.remove({});                                                   // 3
    Reviews.remove({});                                                // 4
    if (Bakery.find().count() === 0) {                                 // 5
        var items = [{                                                 // 6
            name: "Sesame Bagel",                                      // 8
            calories: 230,                                             // 9
            fat: 3,                                                    // 10
            carb: 25,                                                  // 11
            protein: 5,                                                // 12
            descrip: 'Fresh bagels made daily for optimal satisfaction',
            img: "/img/bagels.jpg"                                     // 14
        }, {                                                           //
            name: "Whole Wheat Bread",                                 // 17
            calories: 250,                                             // 18
            fat: 6,                                                    // 19
            carb: 33,                                                  // 20
            protein: 4,                                                // 21
            descrip: 'Made with 100% Gluten free flour',               // 22
            img: "/img/wholewheat.jpg"                                 // 23
        }, {                                                           //
            name: "Acai Bowl",                                         // 26
            calories: 450,                                             // 27
            fat: 20,                                                   // 28
            carb: 73,                                                  // 29
            protein: 9,                                                // 30
            descrip: 'Power-packed acai bowl with refreshing fruits, granola, and nuts, perfect for starting off the day',
            img: "/img/acai.png"                                       // 32
        }, {                                                           //
            name: "Chocolate Pumpkin Oat Bran Muffin",                 // 35
            calories: 240,                                             // 36
            fat: 9,                                                    // 37
            carb: 38,                                                  // 38
            protein: 6,                                                // 39
            descrip: 'Sweet, fluffy muffins that pair well with a warm tea or coffee in the morning',
            img: "/img/muffins.jpg"                                    // 41
        }, {                                                           //
            name: "Lemon Lavender Half Pound Cake",                    // 44
            calories: 200,                                             // 45
            fat: 10,                                                   // 46
            carb: 29,                                                  // 47
            protein: 5,                                                // 48
            descrip: 'Light, elegant slices of cake with an aromatic and citrus flavor',
            img: "/img/pound.jpg"                                      // 50
        }, {                                                           //
            name: "Chocolate Tarts",                                   // 53
            calories: 200,                                             // 54
            fat: 6,                                                    // 55
            carb: 15,                                                  // 56
            protein: 2,                                                // 57
            descrip: 'Creamy, chocolate filling inside of a crispy gluten free pastry bowl',
            img: "/img/tart.jpg"                                       // 59
        }, {                                                           //
            name: "Tricolor Mocha Latte",                              // 62
            calories: 257,                                             // 63
            fat: 5,                                                    // 64
            carb: 34,                                                  // 65
            protein: 3,                                                // 66
            descrip: 'A refreshing blast of caffeine at any time of the day',
            img: "/img/latte.jpg"                                      // 68
        }];                                                            //
        _.each(items, function (item) {                                // 72
            Bakery.insert(item);                                       // 73
        });                                                            //
    }                                                                  //
                                                                       //
    if (Menu.find().count() === 0) {                                   // 77
        items = [{                                                     // 78
            name: "BLT Chopped Salad",                                 // 80
            calories: 500,                                             // 81
            fat: 8,                                                    // 82
            carb: 25,                                                  // 83
            protein: 2,                                                // 84
            descrip: 'Your favorite Bacon Lettuce Tomato sandwich, but healthier.',
            img: "/img/bltsalad.jpg",                                  // 86
            type: 'salad'                                              // 87
        }, {                                                           //
            name: "Kale Salad with Bacon and Parmesan",                // 90
            calories: 430,                                             // 91
            fat: 5,                                                    // 92
            carb: 19,                                                  // 93
            protein: 1,                                                // 94
            descrip: 'Superfood kale mixed with crunchy bacon and a pinch of parmesan',
            img: "/img/kalesalad.jpg",                                 // 96
            type: 'salad'                                              // 97
                                                                       //
        }, {                                                           //
            name: "Summer Salad",                                      // 101
            calories: 420,                                             // 102
            fat: 2,                                                    // 103
            carb: 31,                                                  // 104
            protein: 1,                                                // 105
            descrip: 'A unique, refreshing twist on a fruit salad',    // 106
            img: "/img/summersalad.jpg",                               // 107
            type: 'salad'                                              // 108
        }, {                                                           //
            name: "Burrata, Tomato, and Peach Salad",                  // 111
            calories: 390,                                             // 112
            fat: 4,                                                    // 113
            carb: 26,                                                  // 114
            protein: 1,                                                // 115
            descrip: 'A surprisingly delicious combination of sweet and tangy ',
            img: "/img/tomatosalad.jpg",                               // 117
            type: 'salad'                                              // 118
        }, {                                                           //
            name: "Crab Cakes",                                        // 121
            calories: 550,                                             // 122
            fat: 7,                                                    // 123
            carb: 35,                                                  // 124
            protein: 16,                                               // 125
            descrip: 'Flavorful dish made of fresh crab perfected with herbs and spices',
            img: "/img/crabcakes.jpg",                                 // 127
            type: 'entree'                                             // 128
        }, {                                                           //
            name: "Mac and Cheese",                                    // 131
            calories: 490,                                             // 132
            fat: 15,                                                   // 133
            carb: 30,                                                  // 134
            protein: 5,                                                // 135
            descrip: 'Classic cheesy, warm, and gooey macaroni served with gluten free bread sticks',
            img: "/img/maccheese.jpg",                                 // 137
            type: 'entree'                                             // 138
        }, {                                                           //
            name: "Pork Loin with Garlic and Rosemary",                // 141
            calories: 660,                                             // 142
            fat: 5,                                                    // 143
            carb: 20,                                                  // 144
            protein: 19,                                               // 145
            descrip: 'Lean cut of free range chicken with crisp asparagus',
            img: "/img/porkloin.jpg",                                  // 147
            type: 'entree'                                             // 148
        }, {                                                           //
            name: "Steak with Vegetable Salad",                        // 151
            calories: 690,                                             // 152
            fat: 9,                                                    // 153
            carb: 24,                                                  // 154
            protein: 20,                                               // 155
            descrip: 'Tender beef steak paired with a balanced, locally-picked vegetable salad',
            img: "/img/steak.jpg",                                     // 157
            type: 'entree'                                             // 158
        }, {                                                           //
            name: "Lasagna-Style Pasta Bake",                          // 161
            calories: 500,                                             // 162
            fat: 13,                                                   // 163
            carb: 38,                                                  // 164
            protein: 5,                                                // 165
            descrip: 'Al Dente pasta packed with juicy tomato sauce and mozzarella ',
            img: "/img/pasta.jpg",                                     // 167
            type: 'entree'                                             // 168
        }, {                                                           //
            name: "Caprese Panini",                                    // 171
            calories: 550,                                             // 172
            fat: 10,                                                   // 173
            carb: 29,                                                  // 174
            protein: 15,                                               // 175
            descrip: 'Gluten free bread pressed to a crisp with the classic Italian combination',
            img: "/img/capresepanini.jpg",                             // 177
            type: 'entree'                                             // 178
        }, {                                                           //
            name: "Mini Pizzas",                                       // 181
            calories: 300,                                             // 182
            fat: 7,                                                    // 183
            carb: 27,                                                  // 184
            protein: 6,                                                // 185
            descrip: 'Classic made with in-house baked English muffins, smokey pepperoni, and mozzarella cheese',
            img: "/img/minipizza.jpg",                                 // 187
            type: 'kids'                                               // 188
        }, {                                                           //
            name: "Pretzel-Crusted Chicken Fingers",                   // 191
            calories: 500,                                             // 192
            fat: 13,                                                   // 193
            carb: 38,                                                  // 194
            protein: 5,                                                // 195
            descrip: 'Juicy, tender chicken with an extra crunchy pretzel based exterior',
            img: "/img/chickenfingers.jpg",                            // 197
            type: 'kids'                                               // 198
        }, {                                                           //
            name: "Turkey Lettuce Wraps",                              // 201
            calories: 290,                                             // 202
            fat: 4,                                                    // 203
            carb: 29,                                                  // 204
            protein: 10,                                               // 205
            descrip: 'Delicious, healthy, and easy to eat',            // 206
            img: "/img/wraps.jpg",                                     // 207
            type: 'kids'                                               // 208
        }];                                                            //
        _.each(items, function (item) {                                // 211
            Menu.insert(item);                                         // 212
        });                                                            //
    }                                                                  //
    if (Reviews.find().count() === 0) {                                // 215
        items = [{                                                     // 216
            name: "Wendy U.",                                          // 218
            text: "The food was delicious! I got the chicken dish and my son got mac and cheese. Next time we’ll bring the rest of the family!"
        }, {                                                           //
            name: "Justin K.",                                         // 222
            text: "the acai bowl was surprisingly filling! It’s kind of like frozen yogurt with a healthy twist. 5/5 would recommend"
                                                                       //
        }, {                                                           //
            name: "Matthew M.",                                        // 227
            text: "Came here with my friend and tried the peach and tomato salad. Definitely needs some getting used to for me but my friend liked it. I’ll have to come again and try out some of the bakery goods"
        }, {                                                           //
            name: "James W.",                                          // 231
            text: "Dropped by for my lunch break and it was packed! Almost didn’t make it back on time. Had to Grab a panini and go. Aside from the time, the gluten free bread was a plus."
        }];                                                            //
        _.each(items, function (item) {                                // 236
            Reviews.insert(item);                                      // 237
        });                                                            //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
