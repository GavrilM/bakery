(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// common.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Bakery = new Mongo.Collection("bakery");                               // 1
Menu = new Mongo.Collection("menu");                                   // 2
Reviews = new Mongo.Collection("reviews");                             // 3
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=common.js.map
